// 📁 advanced-tables.js
// نظام الجداول المتقدمة للقياسات

class OneRailSystem {
    constructor() {
        this.whiteBallOptions = [];
        this.aimOptions = [];
        this.oneRailTable = {};
        
        this.loadFromStorage();
    }
    
    getMeasurements(whiteBall, aim) {
        const closestWhiteBall = this.findClosest(whiteBall, this.whiteBallOptions);
        const target = aim === 'جيب الزاوية' ? 'جيب الزاوية' : parseFloat(aim);
        
        if (this.oneRailTable[closestWhiteBall] && 
            this.oneRailTable[closestWhiteBall][target]) {
            return this.oneRailTable[closestWhiteBall][target];
        }
        
        return null;
    }
    
    findClosest(value, array) {
        if (array.length === 0) return value;
        return array.reduce((prev, curr) => {
            return Math.abs(curr - value) < Math.abs(prev - value) ? curr : prev;
        });
    }
    
    loadFromStorage() {
        try {
            const savedTable = localStorage.getItem('1rail_table');
            const savedOptions = localStorage.getItem('1rail_whiteBall_options');
            
            if (savedTable) this.oneRailTable = JSON.parse(savedTable);
            if (savedOptions) this.whiteBallOptions = JSON.parse(savedOptions);
        } catch (e) {
            console.error('فشل تحميل جدول جدار واحد:', e);
        }
    }
    
    saveToStorage() {
        try {
            localStorage.setItem('1rail_table', JSON.stringify(this.oneRailTable));
            localStorage.setItem('1rail_whiteBall_options', JSON.stringify(this.whiteBallOptions));
        } catch (e) {
            console.error('فشل حفظ جدول جدار واحد:', e);
        }
    }
}

class TwoRailsSystem {
    constructor() {
        this.whiteBallOptions = [];
        this.aimOptions = [];
        this.twoRailsTable = {};
        
        this.loadFromStorage();
    }
    
    getMeasurements(whiteBall, aim) {
        const closestWhiteBall = this.findClosest(whiteBall, this.whiteBallOptions);
        const target = aim === 'جيب الزاوية' ? 'جيب الزاوية' : parseFloat(aim);
        
        if (this.twoRailsTable[closestWhiteBall] && 
            this.twoRailsTable[closestWhiteBall][target]) {
            return this.twoRailsTable[closestWhiteBall][target];
        }
        
        return null;
    }
    
    findClosest(value, array) {
        if (array.length === 0) return value;
        return array.reduce((prev, curr) => {
            return Math.abs(curr - value) < Math.abs(prev - value) ? curr : prev;
        });
    }
    
    loadFromStorage() {
        try {
            const savedTable = localStorage.getItem('2rails_table');
            const savedOptions = localStorage.getItem('2rails_whiteBall_options');
            
            if (savedTable) this.twoRailsTable = JSON.parse(savedTable);
            if (savedOptions) this.whiteBallOptions = JSON.parse(savedOptions);
        } catch (e) {
            console.error('فشل تحميل جدول جدارين:', e);
        }
    }
    
    saveToStorage() {
        try {
            localStorage.setItem('2rails_table', JSON.stringify(this.twoRailsTable));
            localStorage.setItem('2rails_whiteBall_options', JSON.stringify(this.whiteBallOptions));
        } catch (e) {
            console.error('فشل حفظ جدول جدارين:', e);
        }
    }
}

class ThreeRailsSystem {
    constructor() {
        this.whiteBallOptions = [
            0, 0.3, 0.5, 0.7, 0.9, 1, 1.1, 1.25, 1.4, 1.5, 1.6, 1.75, 1.9,
            2, 2.1, 2.25, 2.4, 2.5, 2.6, 2.75, 2.9, 3, 3.1, 3.4, 3.5
        ];
        
        this.aimOptions = [4, 5, 5.5, 6, 7, 8, 'جيب الزاوية'];
        this.threeRailsTable = {};
        
        this.loadFromStorage();
        this.initializeDefaultTable();
    }
    
    initializeDefaultTable() {
        // فقط إذا كان الجدول فارغاً
        if (Object.keys(this.threeRailsTable).length === 0) {
            this.threeRailsTable = {
                0: {
                    4: { cue: 1.5, path: 1.7 },
                    5: { cue: 2.5, path: 2.1, note: '-' },
                    5.5: { cue: 2.2, path: 2.2, note: '-' },
                    6: { cue: 2.7, path: 2.6 },
                    7: { cue: 3.8, path: 3.2 },
                    8: { cue: 4.6, path: 3.7 },
                    'جيب الزاوية': { cue: 4.8, path: 3.8 }
                },
                0.3: {
                    4: { cue: 1.6, path: 1.6 },
                    5: { cue: 2.1, path: 2.2, note: '-' },
                    5.5: { cue: 2.4, path: 2.2, note: '-' },
                    6: { cue: 2.9, path: 2.5 },
                    7: { cue: 4.7, path: 3.7, note: '-' }
                },
                // ... (يتم تعبئة الباقي عند الإضافة)
            };
        }
    }
    
    getMeasurements(whiteBall, aim) {
        const closestWhiteBall = this.findClosest(whiteBall, this.whiteBallOptions);
        const target = aim === 'جيب الزاوية' ? 'جيب الزاوية' : parseFloat(aim);
        
        if (this.threeRailsTable[closestWhiteBall] && 
            this.threeRailsTable[closestWhiteBall][target]) {
            return this.threeRailsTable[closestWhiteBall][target];
        }
        
        return null;
    }
    
    findClosest(value, array) {
        if (array.length === 0) return value;
        return array.reduce((prev, curr) => {
            return Math.abs(curr - value) < Math.abs(prev - value) ? curr : prev;
        });
    }
    
    loadFromStorage() {
        try {
            const savedTable = localStorage.getItem('3rails_table');
            const savedOptions = localStorage.getItem('3rails_whiteBall_options');
            
            if (savedTable) {
                const parsed = JSON.parse(savedTable);
                this.threeRailsTable = {};
                
                for (const whiteBall in parsed) {
                    const newRow = {};
                    for (const aim in parsed[whiteBall]) {
                        if (aim === 'جيب الزاوية') {
                            newRow[aim] = parsed[whiteBall][aim];
                        } else {
                            newRow[parseFloat(aim)] = parsed[whiteBall][aim];
                        }
                    }
                    this.threeRailsTable[parseFloat(whiteBall)] = newRow;
                }
            }
            if (savedOptions) {
                this.whiteBallOptions = JSON.parse(savedOptions);
            }
        } catch (e) {
            console.error('فشل تحميل جدول ثلاثة جدران:', e);
        }
    }
    
    saveToStorage() {
        try {
            localStorage.setItem('3rails_table', JSON.stringify(this.threeRailsTable));
            localStorage.setItem('3rails_whiteBall_options', JSON.stringify(this.whiteBallOptions));
        } catch (e) {
            console.error('فشل حفظ جدول ثلاثة جدران:', e);
        }
    }
}

class FourRailsSystem {
    constructor() {
        this.whiteBallOptions = [];
        this.aimOptions = [];
        this.fourRailsTable = {};
        
        this.loadFromStorage();
    }
    
    getMeasurements(whiteBall, aim) {
        const closestWhiteBall = this.findClosest(whiteBall, this.whiteBallOptions);
        const target = aim === 'جيب الزاوية' ? 'جيب الزاوية' : parseFloat(aim);
        
        if (this.fourRailsTable[closestWhiteBall] && 
            this.fourRailsTable[closestWhiteBall][target]) {
            return this.fourRailsTable[closestWhiteBall][target];
        }
        
        return null;
    }
    
    findClosest(value, array) {
        if (array.length === 0) return value;
        return array.reduce((prev, curr) => {
            return Math.abs(curr - value) < Math.abs(prev - value) ? curr : prev;
        });
    }
    
    loadFromStorage() {
        try {
            const savedTable = localStorage.getItem('4rails_table');
            const savedOptions = localStorage.getItem('4rails_whiteBall_options');
            
            if (savedTable) this.fourRailsTable = JSON.parse(savedTable);
            if (savedOptions) this.whiteBallOptions = JSON.parse(savedOptions);
        } catch (e) {
            console.error('فشل تحميل جدول أربعة جدران:', e);
        }
    }
    
    saveToStorage() {
        try {
            localStorage.setItem('4rails_table', JSON.stringify(this.fourRailsTable));
            localStorage.setItem('4rails_whiteBall_options', JSON.stringify(this.whiteBallOptions));
        } catch (e) {
            console.error('فشل حفظ جدول أربعة جدران:', e);
        }
    }
}

// تصدير الأنظمة
window.OneRailSystem = OneRailSystem;
window.TwoRailsSystem = TwoRailsSystem;
window.ThreeRailsSystem = ThreeRailsSystem;
window.FourRailsSystem = FourRailsSystem;
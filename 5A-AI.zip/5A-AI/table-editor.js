// 📁 table-editor.js
class TableEditor {
    constructor() {
        this.currentRails = 3;
        this.currentTable = null;
        this.editedValues = {};
        
        this.init();
    }
    
    init() {
        this.loadCurrentTable();
        this.setupEventListeners();
        this.renderTable();
        
        console.log('محرر الجداول جاهز');
    }
    
    loadCurrentTable() {
        const rails = parseInt(this.currentRails);
        
        if (rails === 3) {
            this.currentTable = new ThreeRailsSystem();
        } else if (rails === 2) {
            this.currentTable = new TwoRailsSystem();
        } else if (rails === 4) {
            this.currentTable = new FourRailsSystem();
        } else if (rails === 1) {
            this.currentTable = new OneRailSystem();
        }
        
        // تحميل البيانات المحفوظة
        if (this.currentTable && typeof this.currentTable.loadFromStorage === 'function') {
            this.currentTable.loadFromStorage();
        }
    }
    
    setupEventListeners() {
        // تغيير عدد الجدران
        document.getElementById('railsSelect').addEventListener('change', (e) => {
            this.currentRails = parseInt(e.target.value);
            this.loadCurrentTable();
            this.renderTable();
            this.showStatus('تم تحميل جدول ' + this.currentRails + ' جدران');
        });
        
        // تحميل الجدول
        document.getElementById('loadTableBtn').addEventListener('click', () => {
            this.loadCurrentTable();
            this.renderTable();
            this.showStatus('تم تحديث الجدول');
        });
        
        // حفظ الجدول
        document.getElementById('saveTableBtn').addEventListener('click', () => {
            this.saveChanges();
        });
        
        // إضافة صف
        document.getElementById('addRowBtn').addEventListener('click', () => {
            this.openAddRowModal();
        });
        
        // إضافة عمود
        document.getElementById('addColumnBtn').addEventListener('click', () => {
            this.openAddColumnModal();
        });
        
        // استيراد
        document.getElementById('importBtn').addEventListener('click', () => {
            this.importTable();
        });
        
        // تصدير
        document.getElementById('exportBtn').addEventListener('click', () => {
            this.exportTable();
        });
        
        // استعادة الافتراضيات
        document.getElementById('resetBtn').addEventListener('click', () => {
            if (confirm('هل تريد استعادة الجدول إلى القيم الافتراضية؟ سيتم فقدان جميع التعديلات.')) {
                this.resetTable();
            }
        });
        
        // العودة للتطبيق
        document.getElementById('backToAppBtn').addEventListener('click', () => {
            window.location.href = 'index.html';
        });
        
        // تطبيق JSON
        document.getElementById('applyJsonBtn').addEventListener('click', () => {
            this.applyJson();
        });
        
        // نسخ JSON
        document.getElementById('copyJsonBtn').addEventListener('click', () => {
            this.copyJson();
        });
        
        // تأكيد إضافة صف
        document.getElementById('confirmAddRow').addEventListener('click', () => {
            this.addNewRow();
        });
        
        // تأكيد إضافة عمود
        document.getElementById('confirmAddColumn').addEventListener('click', () => {
            this.addNewColumn();
        });
    }
    
    renderTable() {
        if (!this.currentTable) {
            this.showError('الجدول غير متوفر');
            return;
        }
        
        // تحديد اسم الخاصية بناءً على عدد الجدران
        let tableData;
        if (this.currentRails === 1) {
            tableData = this.currentTable.oneRailTable;
        } else if (this.currentRails === 2) {
            tableData = this.currentTable.twoRailsTable;
        } else if (this.currentRails === 3) {
            tableData = this.currentTable.threeRailsTable;
        } else if (this.currentRails === 4) {
            tableData = this.currentTable.fourRailsTable;
        }
        
        if (!tableData) {
            this.showError('بيانات الجدول غير متوفرة');
            return;
        }
        
        const whiteBalls = Object.keys(tableData).map(Number).sort((a, b) => a - b);
        const aims = this.getAllAims(tableData);
        
        // بناء الرأس
        const header = document.getElementById('tableHeader');
        header.innerHTML = '';
        
        let headerRow = '<tr>';
        headerRow += '<th class="row-header">قياس الكرة البيضاء</th>';
        
        aims.forEach(aim => {
            headerRow += `<th class="column-header">
                <div>${aim === 'جيب الزاوية' ? aim : 'إلى ' + aim}</div>
                <div class="cell-actions">
                    <button class="btn-danger btn-sm" onclick="tableEditor.deleteColumn('${aim}')">
                        <i class="fas fa-trash"></i>
                    </button>
                </div>
            </th>`;
        });
        
        headerRow += '<th>الإجراءات</th>';
        headerRow += '</tr>';
        
        header.innerHTML = headerRow;
        
        // بناء الجسم
        const body = document.getElementById('tableBody');
        body.innerHTML = '';
        
        whiteBalls.forEach(whiteBall => {
            const row = document.createElement('tr');
            row.innerHTML = this.createRowHTML(whiteBall, aims, tableData[whiteBall]);
            body.appendChild(row);
        });
    }
    
    getAllAims(tableData) {
        const aims = new Set();
        
        for (const whiteBall in tableData) {
            for (const aim in tableData[whiteBall]) {
                aims.add(aim);
            }
        }
        
        // تحويل إلى مصفوفة وترتيب
        return Array.from(aims).sort((a, b) => {
            if (a === 'جيب الزاوية') return 1;
            if (b === 'جيب الزاوية') return -1;
            return parseFloat(a) - parseFloat(b);
        });
    }
    
    createRowHTML(whiteBall, aims, rowData) {
        let html = `<td class="row-header">
            <div><strong>${whiteBall}</strong></div>
            <div class="cell-actions">
                <button class="btn-danger btn-sm" onclick="tableEditor.deleteRow(${whiteBall})">
                    <i class="fas fa-trash"></i>
                </button>
            </div>
        </td>`;
        
        aims.forEach(aim => {
            const cellData = rowData && rowData[aim] ? rowData[aim] : { cue: '', path: '', note: '' };
            
            html += `<td>
                <div class="cell-group">
                    <input type="number" class="cell-input cue-input" 
                           data-whiteball="${whiteBall}" data-aim="${aim}" 
                           data-type="cue" value="${cellData.cue || ''}" 
                           step="0.1" placeholder="العصا"
                           onchange="tableEditor.updateCell(${whiteBall}, '${aim}', 'cue', this.value)">
                    <input type="number" class="cell-input path-input" 
                           data-whiteball="${whiteBall}" data-aim="${aim}" 
                           data-type="path" value="${cellData.path || ''}" 
                           step="0.1" placeholder="المسار"
                           onchange="tableEditor.updateCell(${whiteBall}, '${aim}', 'path', this.value)">
                    <input type="text" class="cell-input cell-note" 
                           data-whiteball="${whiteBall}" data-aim="${aim}" 
                           data-type="note" value="${cellData.note || ''}" 
                           placeholder="ملاحظة"
                           onchange="tableEditor.updateCell(${whiteBall}, '${aim}', 'note', this.value)">
                </div>
            </td>`;
        });
        
        html += `<td>
            <div class="cell-actions">
                <button class="btn-primary btn-sm" onclick="tableEditor.duplicateRow(${whiteBall})">
                    <i class="fas fa-copy"></i> نسخ
                </button>
                <button class="btn-success btn-sm" onclick="tableEditor.saveRow(${whiteBall})">
                    <i class="fas fa-save"></i> حفظ
                </button>
            </div>
        </td>`;
        
        return html;
    }
    
    updateCell(whiteBall, aim, type, value) {
        if (!this.editedValues[whiteBall]) {
            this.editedValues[whiteBall] = {};
        }
        
        if (!this.editedValues[whiteBall][aim]) {
            this.editedValues[whiteBall][aim] = {};
        }
        
        this.editedValues[whiteBall][aim][type] = value;
        
        // تحديث القيمة مباشرة في الجدول
        let tableData;
        if (this.currentRails === 1) {
            tableData = this.currentTable.oneRailTable;
        } else if (this.currentRails === 2) {
            tableData = this.currentTable.twoRailsTable;
        } else if (this.currentRails === 3) {
            tableData = this.currentTable.threeRailsTable;
        } else if (this.currentRails === 4) {
            tableData = this.currentTable.fourRailsTable;
        }
        
        if (!tableData[whiteBall]) {
            tableData[whiteBall] = {};
        }
        
        if (!tableData[whiteBall][aim]) {
            tableData[whiteBall][aim] = {};
        }
        
        tableData[whiteBall][aim][type] = value;
        
        this.showStatus(`تم تحديث ${whiteBall} -> ${aim} (${type})`);
    }
    
    saveChanges() {
        try {
            // حفظ التغييرات في التخزين المحلي
            this.currentTable.saveToStorage();
            
            // تحديث قائمة القياسات
            this.updateWhiteBallOptions();
            
            // مسح التغييرات المحفوظة
            this.editedValues = {};
            
            this.showStatus('تم حفظ جميع التغييرات بنجاح!', 'success');
            
            // إعادة تحميل الجدول
            this.renderTable();
            
        } catch (error) {
            this.showError('فشل حفظ التغييرات: ' + error.message);
        }
    }
    
    updateWhiteBallOptions() {
        let tableData;
        if (this.currentRails === 1) {
            tableData = this.currentTable.oneRailTable;
        } else if (this.currentRails === 2) {
            tableData = this.currentTable.twoRailsTable;
        } else if (this.currentRails === 3) {
            tableData = this.currentTable.threeRailsTable;
        } else if (this.currentRails === 4) {
            tableData = this.currentTable.fourRailsTable;
        }
        
        const whiteBalls = Object.keys(tableData).map(Number).sort((a, b) => a - b);
        this.currentTable.whiteBallOptions = whiteBalls;
    }
    
    openAddRowModal() {
        document.getElementById('addRowModal').style.display = 'flex';
        document.getElementById('newRowValue').focus();
    }
    
    openAddColumnModal() {
        document.getElementById('addColumnModal').style.display = 'flex';
        document.getElementById('newColumnValue').focus();
    }
    
    addNewRow() {
        const value = parseFloat(document.getElementById('newRowValue').value);
        const name = document.getElementById('newRowName').value;
        
        if (isNaN(value)) {
            this.showError('الرجاء إدخال قيمة رقمية صحيحة');
            return;
        }
        
        let tableData;
        if (this.currentRails === 1) {
            tableData = this.currentTable.oneRailTable;
        } else if (this.currentRails === 2) {
            tableData = this.currentTable.twoRailsTable;
        } else if (this.currentRails === 3) {
            tableData = this.currentTable.threeRailsTable;
        } else if (this.currentRails === 4) {
            tableData = this.currentTable.fourRailsTable;
        }
        
        if (tableData[value]) {
            this.showError('هذا القياس موجود بالفعل!');
            return;
        }
        
        // إضافة صف جديد
        tableData[value] = {};
        
        // إضافة إلى القائمة
        if (!this.currentTable.whiteBallOptions.includes(value)) {
            this.currentTable.whiteBallOptions.push(value);
            this.currentTable.whiteBallOptions.sort((a, b) => a - b);
        }
        
        // حفظ
        this.currentTable.saveToStorage();
        
        // إعادة تحميل الجدول
        this.renderTable();
        
        // إغلاق النافذة
        this.closeModal('addRowModal');
        
        // مسح الحقول
        document.getElementById('newRowValue').value = '';
        document.getElementById('newRowName').value = '';
        
        this.showStatus(`تم إضافة قياس كرة بيضاء جديد: ${value}`, 'success');
    }
    
    addNewColumn() {
        const value = document.getElementById('newColumnValue').value;
        const name = document.getElementById('newColumnName').value || value;
        
        if (!value) {
            this.showError('الرجاء إدخال قيمة للعمود');
            return;
        }
        
        let tableData;
        if (this.currentRails === 1) {
            tableData = this.currentTable.oneRailTable;
        } else if (this.currentRails === 2) {
            tableData = this.currentTable.twoRailsTable;
        } else if (this.currentRails === 3) {
            tableData = this.currentTable.threeRailsTable;
        } else if (this.currentRails === 4) {
            tableData = this.currentTable.fourRailsTable;
        }
        
        const aims = this.getAllAims(tableData);
        if (aims.includes(value)) {
            this.showError('هذا الهدف موجود بالفعل!');
            return;
        }
        
        // إضافة العمود لجميع الصفوف
        const whiteBalls = Object.keys(tableData).map(Number);
        
        whiteBalls.forEach(wb => {
            if (!tableData[wb][value]) {
                tableData[wb][value] = { cue: '', path: '', note: '' };
            }
        });
        
        // حفظ
        this.currentTable.saveToStorage();
        
        // إعادة تحميل الجدول
        this.renderTable();
        
        // إغلاق النافذة
        this.closeModal('addColumnModal');
        
        // مسح الحقول
        document.getElementById('newColumnValue').value = '';
        document.getElementById('newColumnName').value = '';
        
        this.showStatus(`تم إضافة عمود جديد: ${name}`, 'success');
    }
    
    deleteRow(whiteBall) {
        if (confirm(`هل تريد حذف قياس الكرة البيضاء ${whiteBall} وجميع بياناته؟`)) {
            let tableData;
            if (this.currentRails === 1) {
                tableData = this.currentTable.oneRailTable;
            } else if (this.currentRails === 2) {
                tableData = this.currentTable.twoRailsTable;
            } else if (this.currentRails === 3) {
                tableData = this.currentTable.threeRailsTable;
            } else if (this.currentRails === 4) {
                tableData = this.currentTable.fourRailsTable;
            }
            
            delete tableData[whiteBall];
            
            // تحديث القائمة
            const index = this.currentTable.whiteBallOptions.indexOf(whiteBall);
            if (index > -1) {
                this.currentTable.whiteBallOptions.splice(index, 1);
            }
            
            this.currentTable.saveToStorage();
            this.renderTable();
            
            this.showStatus(`تم حذف قياس الكرة البيضاء ${whiteBall}`, 'warning');
        }
    }
    
    deleteColumn(aim) {
        if (confirm(`هل تريد حذف عمود الهدف ${aim} وجميع بياناته؟`)) {
            let tableData;
            if (this.currentRails === 1) {
                tableData = this.currentTable.oneRailTable;
            } else if (this.currentRails === 2) {
                tableData = this.currentTable.twoRailsTable;
            } else if (this.currentRails === 3) {
                tableData = this.currentTable.threeRailsTable;
            } else if (this.currentRails === 4) {
                tableData = this.currentTable.fourRailsTable;
            }
            
            const whiteBalls = Object.keys(tableData).map(Number);
            
            whiteBalls.forEach(wb => {
                if (tableData[wb][aim]) {
                    delete tableData[wb][aim];
                }
            });
            
            this.currentTable.saveToStorage();
            this.renderTable();
            
            this.showStatus(`تم حذف عمود الهدف ${aim}`, 'warning');
        }
    }
    
    duplicateRow(whiteBall) {
        const newValue = parseFloat(prompt('أدخل القيمة الجديدة لنسخ هذا الصف:', whiteBall + 0.1));
        
        if (isNaN(newValue)) {
            this.showError('قيمة غير صالحة');
            return;
        }
        
        let tableData;
        if (this.currentRails === 1) {
            tableData = this.currentTable.oneRailTable;
        } else if (this.currentRails === 2) {
            tableData = this.currentTable.twoRailsTable;
        } else if (this.currentRails === 3) {
            tableData = this.currentTable.threeRailsTable;
        } else if (this.currentRails === 4) {
            tableData = this.currentTable.fourRailsTable;
        }
        
        if (tableData[newValue]) {
            this.showError('هذه القيمة موجودة بالفعل!');
            return;
        }
        
        // نسخ البيانات
        tableData[newValue] = JSON.parse(JSON.stringify(tableData[whiteBall]));
        
        // إضافة إلى القائمة
        if (!this.currentTable.whiteBallOptions.includes(newValue)) {
            this.currentTable.whiteBallOptions.push(newValue);
            this.currentTable.whiteBallOptions.sort((a, b) => a - b);
        }
        
        this.currentTable.saveToStorage();
        this.renderTable();
        
        this.showStatus(`تم نسخ الصف ${whiteBall} إلى ${newValue}`, 'success');
    }
    
    saveRow(whiteBall) {
        // حفظ الصف المحدد فقط
        const rowInputs = document.querySelectorAll(`input[data-whiteball="${whiteBall}"]`);
        
        rowInputs.forEach(input => {
            const aim = input.dataset.aim;
            const type = input.dataset.type;
            const value = input.value;
            
            this.updateCell(whiteBall, aim, type, value);
        });
        
        this.currentTable.saveToStorage();
        this.showStatus(`تم حفظ صف ${whiteBall} بنجاح`, 'success');
    }
    
    importTable() {
        const jsonText = prompt('الصق محتوى JSON للجدول:');
        
        if (!jsonText) return;
        
        try {
            const importedData = JSON.parse(jsonText);
            
            // التحقق من الهيكل
            if (typeof importedData === 'object' && importedData !== null) {
                let tableData;
                if (this.currentRails === 1) {
                    this.currentTable.oneRailTable = importedData;
                } else if (this.currentRails === 2) {
                    this.currentTable.twoRailsTable = importedData;
                } else if (this.currentRails === 3) {
                    this.currentTable.threeRailsTable = importedData;
                } else if (this.currentRails === 4) {
                    this.currentTable.fourRailsTable = importedData;
                }
                
                this.currentTable.saveToStorage();
                this.renderTable();
                this.showStatus('تم استيراد الجدول بنجاح!', 'success');
            } else {
                this.showError('تنسيق JSON غير صالح');
            }
        } catch (error) {
            this.showError('خطأ في تحليل JSON: ' + error.message);
        }
    }
    
    exportTable() {
        let tableData;
        if (this.currentRails === 1) {
            tableData = this.currentTable.oneRailTable;
        } else if (this.currentRails === 2) {
            tableData = this.currentTable.twoRailsTable;
        } else if (this.currentRails === 3) {
            tableData = this.currentTable.threeRailsTable;
        } else if (this.currentRails === 4) {
            tableData = this.currentTable.fourRailsTable;
        }
        
        const jsonString = JSON.stringify(tableData, null, 2);
        const textarea = document.getElementById('jsonEditor');
        textarea.value = jsonString;
        
        // نسخ إلى الحافظة
        navigator.clipboard.writeText(jsonString).then(() => {
            this.showStatus('تم نسخ الجدول إلى الحافظة', 'success');
        }).catch(() => {
            this.showStatus('يمكنك نسخ الجدول يدوياً من مربع النص', 'info');
        });
    }
    
    applyJson() {
        const jsonText = document.getElementById('jsonEditor').value;
        
        if (!jsonText) {
            this.showError('الرجاء إدخال JSON صالح');
            return;
        }
        
        try {
            const importedData = JSON.parse(jsonText);
            
            // استبدال الجدول الحالي
            if (this.currentRails === 1) {
                this.currentTable.oneRailTable = importedData;
            } else if (this.currentRails === 2) {
                this.currentTable.twoRailsTable = importedData;
            } else if (this.currentRails === 3) {
                this.currentTable.threeRailsTable = importedData;
            } else if (this.currentRails === 4) {
                this.currentTable.fourRailsTable = importedData;
            }
            
            this.currentTable.saveToStorage();
            this.renderTable();
            
            this.showStatus('تم تطبيق JSON بنجاح!', 'success');
        } catch (error) {
            this.showError('خطأ في تحليل JSON: ' + error.message);
        }
    }
    
    copyJson() {
        let tableData;
        if (this.currentRails === 1) {
            tableData = this.currentTable.oneRailTable;
        } else if (this.currentRails === 2) {
            tableData = this.currentTable.twoRailsTable;
        } else if (this.currentRails === 3) {
            tableData = this.currentTable.threeRailsTable;
        } else if (this.currentRails === 4) {
            tableData = this.currentTable.fourRailsTable;
        }
        
        const jsonString = JSON.stringify(tableData, null, 2);
        
        navigator.clipboard.writeText(jsonString).then(() => {
            this.showStatus('تم نسخ JSON إلى الحافظة', 'success');
        }).catch(() => {
            // طريقة بديلة
            const textarea = document.createElement('textarea');
            textarea.value = jsonString;
            document.body.appendChild(textarea);
            textarea.select();
            document.execCommand('copy');
            document.body.removeChild(textarea);
            this.showStatus('تم النسخ', 'success');
        });
    }
    
    resetTable() {
        // استعادة الجدول الافتراضي
        if (this.currentRails === 1) {
            this.currentTable = new OneRailSystem();
        } else if (this.currentRails === 2) {
            this.currentTable = new TwoRailsSystem();
        } else if (this.currentRails === 3) {
            this.currentTable = new ThreeRailsSystem();
        } else if (this.currentRails === 4) {
            this.currentTable = new FourRailsSystem();
        }
        
        this.currentTable.saveToStorage();
        this.renderTable();
        
        this.showStatus('تم استعادة الجدول إلى الإعدادات الافتراضية', 'warning');
    }
    
    closeModal(modalId) {
        document.getElementById(modalId).style.display = 'none';
    }
    
    showStatus(message, type = 'info') {
        const statusBar = document.getElementById('statusBar');
        statusBar.textContent = message;
        statusBar.style.display = 'block';
        
        // تلوين حسب النوع
        if (type === 'success') {
            statusBar.style.background = '#00b894';
        } else if (type === 'error') {
            statusBar.style.background = '#ff7675';
        } else if (type === 'warning') {
            statusBar.style.background = '#fdcb6e';
            statusBar.style.color = '#000';
        } else {
            statusBar.style.background = '#00d2d3';
        }
        
        // إخفاء بعد 3 ثواني
        setTimeout(() => {
            statusBar.style.display = 'none';
        }, 3000);
    }
    
    showError(message) {
        this.showStatus('❌ ' + message, 'error');
    }
}

// إنشاء نسخة عالمية
const tableEditor = new TableEditor();

// دوال مساعدة للوصول من الأزرار
window.tableEditor = tableEditor;

window.closeModal = function(modalId) {
    tableEditor.closeModal(modalId);
};